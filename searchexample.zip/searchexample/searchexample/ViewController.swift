//
//  ViewController.swift
//  searchexample
//
//  Created by TOPS on 8/31/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit


class ViewController: UIViewController,UISearchBarDelegate,UITableViewDataSource,UITableViewDelegate{

    @IBOutlet weak var searchbar: UISearchBar!
    
    @IBOutlet weak var tbl: UITableView!
    
    
    var arr :[[String:String]] = [];
    
    var searchEnabled : Bool = false;
    
    var searchresult : [[String:String]] = [];
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getdata();
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if searchEnabled == true {
            
            return  searchresult.count
            
        }
        else
        {
            
            print(arr);
            
            return  arr.count;
            
        }
        
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        
        
        if searchEnabled == true {
            
            let dic = searchresult[indexPath.row] ;
            
            cell.textLabel?.text = dic["emp_name"] ;
            
            cell.detailTextLabel?.text = dic["emp_add"];
            
        }
        else
        {
            let dic = arr[indexPath.row] ;
            
            cell.textLabel?.text = dic["emp_name"] ;
            
            cell.detailTextLabel?.text = dic["emp_add"];
            
        }
        
        
        
        
        return cell
    }
    
    

    func getdata() {
        
          let dic1 = ["emp_name":"abc","emp_add":"surat"]
         let dic2 = ["emp_name":"def","emp_add":"navsari"]
         let dic3 = ["emp_name":"ghi","emp_add":"rajkot"]
         let dic4 = ["emp_name":"jkl","emp_add":"amd"]
        let dic5 = ["emp_name":"mno","emp_add":"sdfs"];
        
        arr.append(dic1);
        arr.append(dic2);
        arr.append(dic3);
        arr.append(dic4);
        arr.append(dic5);
        
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
       
        if searchText.characters.count == 0 {
            
            searchEnabled = false;
            
            tbl.reloadData();
            
        }
        else
        {
            searchEnabled = true;
            
            self  .filtertext(searchtext: searchText);
            
            
        }
        
        
    }
    
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        searchBar.resignFirstResponder();
        searchEnabled = true;
        self.filtertext(searchtext: searchBar.text!);
        
        
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar)
    {
        
        searchBar.resignFirstResponder();
        searchEnabled = false;
        searchBar.text = "";
        self.filtertext(searchtext: searchBar.text!)
    }
    func filtertext(searchtext : String) {
        
        
        
        let namePredicate =
            NSPredicate(format: "self.emp_name contains[c] %@|| self.emp_add contains[c]%@",searchtext,searchtext);
        
        searchresult =  arr.filter { namePredicate.evaluate(with: $0) }
        tbl.reloadData();
    }

    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


 
    
}

